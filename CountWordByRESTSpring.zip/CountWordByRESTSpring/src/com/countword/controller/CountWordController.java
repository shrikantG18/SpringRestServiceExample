package com.countword.controller;

import java.util.HashMap;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.countword.model.Result;
import com.countword.model.WordList;
import com.countword.util.BasicAuthorization;
import com.countword.util.WordMapIntialize;

@Controller
public class CountWordController {
	@Autowired
	private ServletContext servletContext;

	private final Map<String, Integer> wordCount = new LinkedHashMap<>();

	@RequestMapping(value = "/rest/search", method = RequestMethod.POST)
	public @ResponseBody Result getCountOfWords(
			@RequestBody WordList searchText,
			@RequestHeader(value = "Authorization") String authorization) {
		
		if (!BasicAuthorization.isUserAuthenticated(authorization))
			return null;

		if (wordCount.size() == 0)
			WordMapIntialize.intializeMap(servletContext, wordCount);

		Result rs = new Result();
		rs.setWordCounts(new HashMap<String, Integer>());
		
		for (String searchWord : searchText.getSearchText()) {
			if (wordCount.containsKey(searchWord)) {
				rs.getWordCounts().put(searchWord, wordCount.get(searchWord));
			} else {
				rs.getWordCounts().put(searchWord, 0);
			}
		}
		return rs;
	}

	@RequestMapping(value = "/rest/top/{count}", method = RequestMethod.GET)
	public @ResponseBody Result getTopWordWithCount(
			@PathVariable("count") int count,
			@RequestHeader(value = "Authorization") String authorization) {

		if (!BasicAuthorization.isUserAuthenticated(authorization))
			return null;

		if (wordCount.size() == 0)
			WordMapIntialize.intializeMap(servletContext, wordCount);

		Result rs = new Result();
		rs.setWordCounts(new LinkedHashMap<String, Integer>());
		
		for (Entry<String, Integer> entry : wordCount.entrySet()) {
			if (count == 0)
				break;
			rs.getWordCounts().put(entry.getKey(), entry.getValue());			
			count--;
		}
		
		return rs;
	}

}
