package com.countword.model;

import java.io.Serializable;
import java.util.Map;

public class Result implements Serializable {
	private Map<String, Integer> wordCounts;

	public Map<String, Integer> getWordCounts() {
		return wordCounts;
	}

	public void setWordCounts(Map<String, Integer> wordCounts) {
		this.wordCounts = wordCounts;
	}
}
