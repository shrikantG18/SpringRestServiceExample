package com.countword.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class WordList implements Serializable {

	private List<String> searchText;

	public WordList() {
	}

	public List<String> getSearchText() {
		return searchText;
	}

	public void setSearchText(List<String> searchText) {
		this.searchText = searchText;
	}

}
