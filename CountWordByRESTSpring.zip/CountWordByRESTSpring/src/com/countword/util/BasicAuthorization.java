package com.countword.util;

import java.util.Base64;

public class BasicAuthorization {
	public static boolean isUserAuthenticated(String authString) {

		String decodedAuth = "";
		// Header is in the format "Basic 5tyc0uiDat4"
		// We need to extract data before decoding it back to original string
		String[] authParts = authString.split("\\s+");
		String authInfo = authParts[1];
		// Decode the data back to original string
		byte[] bytes = null;
		bytes = Base64.getDecoder().decode(authInfo);
		decodedAuth = new String(bytes);
		System.out.println(decodedAuth);
		if (decodedAuth.equals("optus:candidates")) {
			return true;
		}
		return false;
	}
}
